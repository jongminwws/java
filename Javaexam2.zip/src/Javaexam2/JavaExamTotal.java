package Javaexam2;

public class JavaExamTotal {
    public static int getTotal(JavaExam2 student) {
        return student.kor + student.eng + student.math;
    }
}
