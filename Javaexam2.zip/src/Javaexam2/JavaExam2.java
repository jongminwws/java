package Javaexam2;

public class JavaExam2 {
    String name;
    int ban;
    int no;
    int kor;
    int eng;
    int math;

    public JavaExam2(String name, int ban, int no, int kor, int eng, int math) {
        this.name = name;
        this.ban = ban;
        this.no = no;
        this.kor = kor;
        this.eng = eng;
        this.math = math;
    }
}
